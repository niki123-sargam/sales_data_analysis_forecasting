import pandas as pd
from pathlib import Path

# Define file path safely
file_path = Path(__file__).parent.parent / "data" / "retail_sales.csv"

# Load dataset
df = pd.read_csv(file_path)

# Show first 5 rows
print(df.head())

# Show shape (rows, columns)
print(df.shape)

# Show column names
print(df.columns)

print(df.info())

df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)
                                                                                                                           